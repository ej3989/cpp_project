#include "car.h"
#include "stockmanagecar.h"
#include <iostream>
#include <string>
using namespace std;

int main(){
    stockManageCar A("HMC", "Hybrid", "avante","red","sedan",1000,30);
    cout<<A.getSale()<<endl;
    cout<<A.getQuantity()<<endl;
    cout<<A.getBrand()<<endl;
    cout<<A.getEngine()<<endl;
    cout<<A.getCarName()<<endl;
    cout<<A.getColor()<<endl;
    cout<<A.getType()<<endl;
    return 0;
}